"""Figure 1: daily-order distributions by weekday and daily trend."""
import pandas as pd
import numpy as np
import matplotlib.dates as mdates
from nyc_plot_style import *

daily = pd.read_csv(DATA / 'daily.csv', parse_dates=['date']).sort_values('date')
fig, axs = plt.subplots(1, 2, figsize=(9.4, 3.05), layout='constrained',
                        gridspec_kw={'width_ratios': [1, 1.6]})
daily['weekday'] = daily.date.dt.dayofweek
groups = [daily.loc[daily.weekday == i, 'orders'] / 1000 for i in range(7)]
bp = axs[0].boxplot(groups, patch_artist=True, widths=.62, showfliers=True,
                    flierprops={'marker':'o', 'markersize':2.8, 'markeredgecolor':'#555555', 'markerfacecolor':'white'},
                    medianprops={'color': '#242424', 'linewidth': 1.2},
                    whiskerprops={'color': '#555555', 'linewidth': .8},
                    capprops={'color': '#555555', 'linewidth': .8})
for box, color in zip(bp['boxes'], [BLUE, BLUE, BLUE, BLUE, BLUE, ORANGE, ORANGE]):
    box.set_facecolor(color); box.set_alpha(.72); box.set_edgecolor('#444444'); box.set_linewidth(.7)
axs[0].set_xticks(range(1, 8), ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'])
axs[0].set_ylabel('Daily orders (thousand)')
axs[0].set_xlabel('Pickup weekday')
axs[0].legend([bp['boxes'][0], bp['boxes'][5]], ['Weekday', 'Weekend'], frameon=False, loc='upper left', fontsize=8)
light_grid(axs[0])
axs[1].plot(daily.date, daily.orders / 1000, color=BLUE, alpha=.35, lw=.8,
            label='Daily orders')
axs[1].plot(daily.date, daily.orders.rolling(7, min_periods=7).mean() / 1000,
            color=BLUE, lw=1.8, label='Trailing 7-day mean')
axs[1].set_ylabel('Daily orders (thousand)')
axs[1].xaxis.set_major_locator(mdates.MonthLocator())
axs[1].xaxis.set_major_formatter(mdates.DateFormatter('%b'))
axs[1].set_xlim(daily.date.min(), daily.date.max())
axs[1].set_xlabel('2025')
axs[1].legend(frameon=False, loc='upper left', fontsize=8)
for ax, tag in zip(axs, ['(a)', '(b)']):
    panel(ax, tag)
    light_grid(ax)
save(fig, '01_volume')
