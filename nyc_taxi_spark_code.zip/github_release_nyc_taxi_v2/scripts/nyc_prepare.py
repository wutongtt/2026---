"""HDFS ETL, zone-hour panels and historical features."""
import csv, json, time
from pathlib import Path
from pyspark import StorageLevel
from pyspark.sql import SparkSession, functions as F, Window

OUT=Path('/work/output/nyc_tlc_2025/processed');OUT.mkdir(parents=True,exist_ok=True)
H='hdfs://hadoop:9000/data/nyc_tlc_2025'
spark=(SparkSession.builder.appName('nyc-prepare-hourly-panel').config('spark.sql.session.timeZone','America/New_York').config('spark.sql.shuffle.partitions','32').getOrCreate())
spark.sparkContext.setLogLevel('WARN');start=time.time()
def dump(df,name,order):
    rows=df.orderBy(*order).collect()
    with (OUT/(name+'.csv')).open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=df.columns);w.writeheader();w.writerows([r.asDict() for r in rows])
    return [r.asDict() for r in rows]
frames=[]
for month in range(1,7):
    source=f'2025-{month:02d}'
    r=spark.read.parquet(f'{H}/raw/trips/yellow_tripdata_{source}.parquet')
    frames.append(r.select(F.date_format(F.col('tpep_pickup_datetime').cast('timestamp'),'yyyy-MM-dd HH:mm:ss').alias('pickup_local'),F.date_format(F.col('tpep_dropoff_datetime').cast('timestamp'),'yyyy-MM-dd HH:mm:ss').alias('dropoff_local'),F.col('PULocationID').cast('int').alias('pickup_zone'),F.col('DOLocationID').cast('int').alias('dropoff_zone'),F.col('trip_distance').cast('double'),F.col('total_amount').cast('double'),F.lit(source).alias('source_month')))
ods=frames[0]
for r in frames[1:]:ods=ods.unionByName(r)
audit={'raw_rows':ods.count()}
ods.write.mode('overwrite').parquet(f'{H}/ods/trips')
print('ODS_WRITTEN',audit,flush=True)
ods=spark.read.parquet(f'{H}/ods/trips')
z=(spark.read.option('header',True).csv(f'{H}/raw/zones/taxi_zone_lookup.csv').select(F.col('LocationID').cast('int').alias('pickup_zone'),'Borough','Zone'))
z.write.mode('overwrite').parquet(f'{H}/ods/zones')
r=ods.join(F.broadcast(z),'pickup_zone','left').withColumn('pickup',F.to_timestamp('pickup_local'))
valid_area=F.coalesce(F.col('Borough').isin('Manhattan','Queens','Brooklyn','Bronx','Staten Island','EWR'),F.lit(False))
r=r.withColumn('status',F.when(F.col('pickup').isNull(),'missing_pickup').when(F.date_format('pickup','yyyy-MM')!=F.col('source_month'),'outside_source_month').when(~valid_area,'unknown_zone').otherwise('retained')).persist(StorageLevel.MEMORY_AND_DISK)
status=dump(r.groupBy('status').count(),'cleaning',['status']);audit['cleaning']=status
assert sum(x['count'] for x in status)==audit['raw_rows']
clean=r.filter(F.col('status')=='retained')
audit['scope_rows']=clean.count();assert audit['scope_rows']==24028583
# Select geographic zones exclusively from Jan-Apr training observations.
trainzones=clean.filter(F.col('pickup')<F.to_timestamp(F.lit('2025-05-01 00:00:00'))).select('pickup_zone').distinct()
audit['training_zones']=trainzones.count()
unknown=clean.join(trainzones,'pickup_zone','left_anti')
audit['future_only_zone_rows_excluded']=unknown.count()
kept=clean.join(trainzones,'pickup_zone','inner')
hourly=(kept.withColumn('hour_ts',F.date_trunc('hour','pickup')).groupBy('pickup_zone','hour_ts').agg(F.count('*').cast('double').alias('y')))
# Sequence increments true elapsed hours in TIMESTAMP; skips the nonexistent DST hour.
hours=spark.sql("SELECT explode(sequence(to_timestamp('2025-01-01 00:00:00'),to_timestamp('2025-06-30 23:00:00'),interval 1 hour)) AS hour_ts")
audit['elapsed_hours']=hours.count();assert audit['elapsed_hours']==181*24-1
panel=trainzones.crossJoin(hours).join(hourly,['pickup_zone','hour_ts'],'left').fillna({'y':0.})
panel=(panel.withColumn('date',F.date_format('hour_ts','yyyy-MM-dd')).withColumn('hour',F.hour('hour_ts')).withColumn('weekday',F.pmod(F.dayofweek('hour_ts')+5,F.lit(7))+1).withColumn('is_weekend',(F.dayofweek('hour_ts').isin(1,7)).cast('int')))
# Ascending Unix epoch guarantees strictly consecutive elapsed hours within each zone.
w=Window.partitionBy('pickup_zone').orderBy('hour_ts')
for lag in [1,24,168]:panel=panel.withColumn(f'lag_{lag}',F.lag('y',lag).over(w))
for width in [24,168]:panel=panel.withColumn(f'roll_{width}',F.avg('y').over(w.rowsBetween(-width,-1)))
panel=panel.withColumn('previous_hour',F.lag('hour_ts',1).over(w)).persist(StorageLevel.MEMORY_AND_DISK)
audit['panel_rows_before_warmup']=panel.count();audit['zero_hour_rows']=panel.filter(F.col('y')==0).count()
audit['non_consecutive_hours']=panel.filter(F.col('previous_hour').isNotNull()&((F.col('hour_ts').cast('long')-F.col('previous_hour').cast('long'))!=3600)).count();assert audit['non_consecutive_hours']==0
samples=(panel.dropna(subset=['lag_168']).drop('previous_hour').withColumn('split',F.when(F.col('date')<'2025-05-01','train').when(F.col('date')<'2025-06-01','validation').otherwise('test')))
samples.repartition(16).write.mode('overwrite').partitionBy('split').parquet(f'{H}/dws/samples')
samples=spark.read.parquet(f'{H}/dws/samples')
audit['samples']=dump(samples.groupBy('split').agg(F.count('*').alias('rows'),F.sum('y').alias('orders'),F.sum((F.col('y')==0).cast('long')).alias('zero_rows'),F.min('date').alias('first_date'),F.max('date').alias('last_date')),'split_summary',['split'])
assert sum(x['rows'] for x in audit['samples'])==audit['training_zones']*(audit['elapsed_hours']-168)
audit['sample_rows']=sum(x['rows'] for x in audit['samples'])
# Train-only representatives, decided before seeing test predictions.
ranking=kept.filter(F.col('pickup')<'2025-05-01').groupBy('pickup_zone').count().orderBy(F.desc('count'))
reps=ranking.limit(3).collect();audit['representative_zones']=[x.pickup_zone for x in reps]
dump(ranking.join(z,'pickup_zone'),'training_zone_ranking',['pickup_zone'])
dump(samples.orderBy('pickup_zone','hour_ts').limit(8).select('pickup_zone','date','hour','y','lag_1','lag_24','lag_168','roll_24','roll_168'),'sample_examples',['pickup_zone','date','hour'])
dump(samples.filter(F.col('split')=='train').groupBy(F.when(F.col('y')==0,'0').when(F.col('y')<=5,'1-5').when(F.col('y')<=20,'6-20').when(F.col('y')<=100,'21-100').otherwise('>100').alias('order_bin')).count(),'target_distribution',['order_bin'])
audit['spark']={'version':spark.version,'master':spark.sparkContext.master,'input_storage':'HDFS','timezone':spark.conf.get('spark.sql.session.timeZone'),'executor_cores':spark.conf.get('spark.executor.cores')}
audit['elapsed_seconds']=time.time()-start
(OUT/'audit.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2,default=str))
print('PREPARE_COMPLETE',json.dumps(audit,default=str),flush=True)
r.unpersist();panel.unpersist();spark.stop()
