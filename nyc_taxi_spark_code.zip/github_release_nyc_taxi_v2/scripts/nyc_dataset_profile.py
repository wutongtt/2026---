"""Profile downloaded TLC files on Spark; write only dataset-description outputs.

Run inside spark-master with spark-submit. All local paths are shared by workers.
This stage does not create model features, train models, or upload data to HDFS.
"""
import csv
import json
import os
import time
from datetime import date, datetime
from pathlib import Path

from pyspark import StorageLevel
from pyspark.sql import SparkSession, functions as F

ROOT = Path('/work')
RAW = ROOT / 'data/nyc_tlc_2025/raw'
OUT = ROOT / 'output/nyc_tlc_2025/dataset'
OUT.mkdir(parents=True, exist_ok=True)
spark = (SparkSession.builder.appName('nyc-tlc-dataset-description')
         .config('spark.sql.session.timeZone', 'America/New_York')
         .config('spark.sql.shuffle.partitions', '16').getOrCreate())
spark.sparkContext.setLogLevel('WARN')
started = time.time()


def write_csv(name, frame, order):
    rows = frame.orderBy(*order).collect()
    with (OUT / (name + '.csv')).open('w', newline='') as handle:
        writer = csv.DictWriter(handle, fieldnames=frame.columns)
        writer.writeheader()
        writer.writerows([row.asDict() for row in rows])
    return [row.asDict() for row in rows]


profiles, frames = [], []
for path in sorted(RAW.glob('yellow_tripdata_2025-*.parquet')):
    month = path.stem[-7:]
    frame = spark.read.parquet('file://' + str(path))
    counts = frame.agg(F.count('*').alias('rows'),
                       *[F.sum(F.col(col).isNull().cast('long')).alias(col)
                         for col in frame.columns]).first().asDict()
    profiles.append({'month': month, 'file': path.name, 'bytes': path.stat().st_size,
                     'rows': counts.pop('rows'), 'null_counts': counts,
                     'schema': frame.schema.jsonValue()})
    frames.append(frame.select(
        F.col('tpep_pickup_datetime').cast('timestamp').alias('pickup'),
        F.col('PULocationID').cast('int').alias('LocationID'),
        F.lit(month).alias('source_month')))
    print('PROFILE', month, profiles[-1]['rows'], flush=True)

raw = frames[0]
for frame in frames[1:]:
    raw = raw.unionByName(frame)
zones = (spark.read.option('header', True).csv('file://' + str(RAW / 'taxi_zone_lookup.csv'))
         .withColumn('LocationID', F.col('LocationID').cast('int')))
assert zones.count() == zones.select('LocationID').distinct().count(), 'Non-unique zone key'
joined = raw.join(F.broadcast(zones), 'LocationID', 'left')
in_scope = F.col('Borough').isin('Manhattan', 'Queens', 'Brooklyn', 'Bronx', 'Staten Island', 'EWR')
classified = joined.withColumn('scope',
    F.when(F.col('pickup').isNull(), 'missing_pickup_time')
     .when(F.date_format('pickup', 'yyyy-MM') != F.col('source_month'), 'outside_source_month')
     .when(~F.coalesce(in_scope, F.lit(False)), 'unknown_pickup_zone')
     .otherwise('in_scope')).persist(StorageLevel.MEMORY_AND_DISK)
audit = write_csv('scope_counts', classified.groupBy('source_month', 'scope')
                  .agg(F.count('*').alias('records')), ['source_month', 'scope'])
assert sum(x['records'] for x in audit) == sum(x['rows'] for x in profiles)
valid = (classified.filter(F.col('scope') == 'in_scope')
         .withColumn('date', F.to_date('pickup'))
         .withColumn('hour', F.hour('pickup'))
         .withColumn('weekday', F.pmod(F.dayofweek('pickup') + 5, F.lit(7)) + 1))
summary = valid.agg(F.count('*').alias('records'),
                    F.date_format(F.min('pickup'), 'yyyy-MM-dd HH:mm:ss').alias('first_pickup'),
                    F.date_format(F.max('pickup'), 'yyyy-MM-dd HH:mm:ss').alias('last_pickup'),
                    F.countDistinct('LocationID').alias('observed_zones'),
                    F.countDistinct('date').alias('observed_days')).first().asDict()
assert summary['records'] == sum(x['records'] for x in audit if x['scope'] == 'in_scope')
write_csv('daily', valid.groupBy('date').agg(F.count('*').alias('orders')), ['date'])
write_csv('monthly', valid.groupBy('source_month').agg(F.count('*').alias('orders')),
          ['source_month'])
write_csv('weekday_hour', valid.groupBy('weekday', 'hour').agg(F.count('*').alias('orders'),
          F.countDistinct('date').alias('days')), ['weekday', 'hour'])
write_csv('borough', valid.groupBy('Borough').agg(F.count('*').alias('orders')),
          ['Borough'])
write_csv('zones', valid.groupBy('LocationID', 'Zone', 'Borough').agg(
          F.count('*').alias('orders')), ['LocationID'])
nulls = []
for col in profiles[0]['null_counts']:
    n = sum(item['null_counts'][col] for item in profiles)
    nulls.append({'field': col, 'null_records': n,
                 'null_percent': 100 * n / sum(x['rows'] for x in profiles)})
with (OUT / 'field_nulls.csv').open('w', newline='') as handle:
    writer = csv.DictWriter(handle, fieldnames=list(nulls[0]))
    writer.writeheader()
    writer.writerows(nulls)
result = {'source': 'NYC TLC Yellow Taxi Trip Records', 'source_year': 2025,
          'source_months': [item['month'] for item in profiles],
          'raw_records': sum(item['rows'] for item in profiles),
          'raw_bytes': sum(item['bytes'] for item in profiles),
          'profiles': profiles, 'scope_summary': summary,
          'scope_definition': 'Pickup month equals filename month; pickup zone has a named geographic borough (NYC five boroughs or EWR). Disjoint exclusions in scope_counts.csv, ordered missing time, outside month, unknown zone.',
          'spark': {'version': spark.version, 'master': spark.sparkContext.master,
                    'timezone': spark.conf.get('spark.sql.session.timeZone'),
                    'storage': 'Shared local file:// input; HDFS ingestion is not part of this stage'},
          'duration_seconds': time.time() - started}
with (OUT / 'profile.json').open('w') as handle:
    json.dump(result, handle, indent=2, ensure_ascii=False, default=str)
print('COMPLETE', json.dumps(summary, default=str), flush=True)
classified.unpersist()
spark.stop()
