CREATE DATABASE IF NOT EXISTS nyc_tlc;
USE nyc_tlc;
SET hive.auto.convert.join=false;
CREATE EXTERNAL TABLE IF NOT EXISTS ods_trips (
  pickup_local STRING,
  dropoff_local STRING,
  pickup_zone INT,
  dropoff_zone INT,
  trip_distance DOUBLE,
  total_amount DOUBLE,
  source_month STRING
) STORED AS PARQUET
LOCATION 'hdfs://hadoop:9000/data/nyc_tlc_2025/ods/trips';
CREATE EXTERNAL TABLE IF NOT EXISTS ods_zones (
  pickup_zone INT,
  Borough STRING,
  Zone STRING
) STORED AS PARQUET
LOCATION 'hdfs://hadoop:9000/data/nyc_tlc_2025/ods/zones';
DESCRIBE ods_trips;
SELECT source_month, COUNT(*) AS trip_rows
FROM ods_trips GROUP BY source_month ORDER BY source_month;
SELECT z.Borough, COUNT(*) AS trip_rows
FROM ods_trips t JOIN ods_zones z ON t.pickup_zone=z.pickup_zone
WHERE substr(t.pickup_local,1,7)=t.source_month
AND z.Borough IN ('Manhattan','Queens','Brooklyn','Bronx','Staten Island','EWR')
GROUP BY z.Borough ORDER BY trip_rows DESC;
