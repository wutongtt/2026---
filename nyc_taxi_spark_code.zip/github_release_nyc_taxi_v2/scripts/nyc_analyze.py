"""Compute evaluation metrics and grouped error summaries."""
from pathlib import Path
import json,glob
import numpy as np,pandas as pd
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/nyc_tlc_2025'
m=json.loads((OUT/'models/metrics.json').read_text())
summary={'metric_checks':{},'diagnostics':{}}
zones=pd.read_csv(ROOT/'data/nyc_tlc_2025/raw/taxi_zone_lookup.csv').rename(columns={'LocationID':'pickup_zone'})
allpred=[]
for model in ['RandomForest','GBT']:
    files=sorted((OUT/'models'/f'{model}_test_predictions').glob('part-*.csv'))
    d=pd.concat([pd.read_csv(f) for f in files],ignore_index=True)
    assert not d.duplicated(['pickup_zone','target_hour']).any()
    assert len(d)==m['counts']['test']
    d['error']=d.prediction-d.y;d['ae']=abs(d.error);d['se']=d.error**2;d['model']=model
    check={'mae':d.ae.mean(),'rmse':np.sqrt(d.se.mean()),'wmape_pct':100*d.ae.sum()/d.y.sum(),'bias_pct':100*d.error.sum()/d.y.sum()}
    for k,v in check.items():assert abs(v-m['test'][model][k])<1e-8,(model,k,v)
    summary['metric_checks'][model]=check
    d=d.merge(zones[['pickup_zone','Borough','Zone']],on='pickup_zone',how='left',validate='many_to_one')
    for key,filename in [('hour','hour'),('Borough','borough'),('pickup_zone','zone')]:
        g=d.groupby(key).agg(n=('y','size'),orders=('y','sum'),ae=('ae','sum'),se=('se','sum'),bias=('error','sum'))
        g['mae']=g.ae/g.n;g['rmse']=np.sqrt(g.se/g.n);g['wmape_pct']=(100*g.ae/g.orders).where(g.orders>0);g['bias_pct']=(100*g.bias/g.orders).where(g.orders>0)
        g.to_csv(OUT/'models'/f'{model}_{filename}_errors.csv')
    neg=d[d.prediction<0]
    summary['diagnostics'][model]={'negative_rows':len(neg),'negative_share_pct':100*len(neg)/len(d),'minimum_prediction':d.prediction.min(),'zero_target_rows':int((d.y==0).sum()),'zero_target_mae':d.loc[d.y==0,'ae'].mean(),'positive_target_mae':d.loc[d.y>0,'ae'].mean()}
    allpred.append(d[['pickup_zone','target_hour','y']].sort_values(['pickup_zone','target_hour']).reset_index(drop=True))
assert allpred[0].equals(allpred[1]),'Models evaluated on different rows or labels'
summary['wmape_absolute_improvement_pp']=m['test']['GBT']['wmape_pct']-m['test']['RandomForest']['wmape_pct']
summary['wmape_relative_improvement_pct']=100*(1-m['test']['RandomForest']['wmape_pct']/m['test']['GBT']['wmape_pct'])
summary['rmse_relative_improvement_pct']=100*(1-m['test']['RandomForest']['rmse']/m['test']['GBT']['rmse'])
(OUT/'models/analysis.json').write_text(json.dumps(summary,indent=2))
print(json.dumps(summary,indent=2))
