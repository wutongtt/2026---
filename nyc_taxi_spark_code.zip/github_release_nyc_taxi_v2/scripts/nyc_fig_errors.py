"""Errors by pickup hour and borough from independently reconciled CSVs."""
import pandas as pd
from nyc_plot_style import *
D=ROOT/'output/nyc_tlc_2025/models'
fig,axs=plt.subplots(1,2,figsize=(9.2,3.0),layout='constrained')
for name,label,color in [('RandomForest','Random forest',BLUE),('GBT','GBT',ORANGE)]:
 h=pd.read_csv(D/f'{name}_hour_errors.csv')
 axs[0].plot(h.hour,h.mae,color=color,lw=1.7,marker='o' if name=='RandomForest' else 's',markevery=3,ms=3.2,label=label)
axs[0].set_xlabel('Target hour (New York local time)');axs[0].set_ylabel('MAE (orders per zone-hour)');axs[0].set_xticks(range(0,24,3));axs[0].legend(frameon=False);light_grid(axs[0])
b1=pd.read_csv(D/'RandomForest_borough_errors.csv').set_index('Borough');b2=pd.read_csv(D/'GBT_borough_errors.csv').set_index('Borough')
keys=['Manhattan','Queens','Brooklyn','Bronx','Staten Island','EWR'];y=list(range(len(keys)))
axs[1].barh([x+.18 for x in y],b1.loc[keys,'wmape_pct'],.32,color=BLUE,label='Random forest')
axs[1].barh([x-.18 for x in y],b2.loc[keys,'wmape_pct'],.32,color=ORANGE,label='GBT')
axs[1].set_yticks(y,keys);axs[1].invert_yaxis();axs[1].set_xlabel('Borough WMAPE (%)');light_grid(axs[1],'x')
for ax,tag in zip(axs,['(a)','(b)']):panel(ax,tag)
save(fig,'08_error_profiles')
