"""Independent invariants for saved hourly features and temporal splits."""
import json
from pathlib import Path
from pyspark.sql import SparkSession,functions as F,Window
H='hdfs://hadoop:9000/data/nyc_tlc_2025'
OUT=Path('/work/output/nyc_tlc_2025/processed')
s=(SparkSession.builder.appName('nyc-independent-feature-audit').config('spark.sql.session.timeZone','America/New_York').config('spark.sql.shuffle.partitions','16').getOrCreate());s.sparkContext.setLogLevel('WARN')
d=s.read.parquet(f'{H}/dws/samples').persist();audit={}
audit['rows']=d.count();audit['duplicate_zone_hours']=d.groupBy('pickup_zone','hour_ts').count().filter('count>1').count();assert audit['duplicate_zone_hours']==0
cols=['y','lag_1','lag_24','lag_168','roll_24','roll_168']
audit['missing_or_negative_cells']=d.filter(' OR '.join(f'{c} IS NULL OR {c}<0' for c in cols)).count();assert audit['missing_or_negative_cells']==0
for lag in [1,24,168]:
    ref=d.select('pickup_zone',(F.col('hour_ts').cast('long')+3600*lag).alias('epoch'),F.col('y').alias('source_y'))
    j=d.withColumn('epoch',F.col('hour_ts').cast('long')).join(ref,['pickup_zone','epoch'],'inner')
    q=j.agg(F.count('*').alias('compared'),F.sum((F.abs(F.col(f'lag_{lag}')-F.col('source_y'))>1e-12).cast('long')).alias('mismatch')).first().asDict();audit[f'lag_{lag}']=q;assert q['mismatch']==0
w=Window.partitionBy('pickup_zone').orderBy('hour_ts')
for width in [24,168]:
    # Exclude the first width rows of saved samples: their source history is in warmup.
    v=d.withColumn('seq',F.row_number().over(w)).withColumn('independent_roll',F.avg('y').over(w.rowsBetween(-width,-1))).filter(F.col('seq')>width)
    bad=v.filter(F.abs(F.col(f'roll_{width}')-F.col('independent_roll'))>1e-9).count();audit[f'roll_{width}_mismatches']=bad;assert bad==0
audit['split_overlap_or_order_errors']=d.filter(((F.col('split')=='train')&(F.col('date')>='2025-05-01'))|((F.col('split')=='validation')&((F.col('date')<'2025-05-01')|(F.col('date')>='2025-06-01')))|((F.col('split')=='test')&(F.col('date')<'2025-06-01'))).count();assert audit['split_overlap_or_order_errors']==0
(OUT/'verification.json').write_text(json.dumps(audit,indent=2));print('AUDIT_PASSED',json.dumps(audit),flush=True);d.unpersist();s.stop()
