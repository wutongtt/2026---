# NYC Taxi Hourly Demand Forecasting with Spark MLlib

This repository contains the executable code for a course project based on the 2025 NYC TLC Yellow Taxi Trip Records. The pipeline stores Parquet data in HDFS, manages detail tables with Hive, builds zone-hour features with Spark, and compares two Spark MLlib regressors:

- `RandomForestRegressor`
- `GBTRegressor`

The target is the observed pickup count for each taxi zone in the next hour. The temporal split uses January-April for training, May for validation, and June for testing. Features include local hour, weekday, zone, historical lags, and rolling means.

## Contents

- `scripts/nyc_dataset_profile.py`: source-file profiling and aggregate summaries.
- `scripts/nyc_prepare.py`: HDFS ETL, zone-hour panel construction, and temporal features.
- `scripts/nyc_hourly_models.py`: validation-based model selection, refitting, and June backtesting.
- `scripts/nyc_analyze.py`: independent metric and error-group summaries.
- `scripts/nyc_verify.py`: temporal feature and split checks.
- `scripts/nyc_fig_*.py`: reproducible figure generation.
- `scripts/sql/nyc_tables.sql`: Hive external tables and SQL checks.
- `spark-cluster/`: Spark and Hadoop configuration used by the scripts.

## Data

Download the official monthly files from:

<https://www.nyc.gov/site/tlc/about/tlc-trip-record-data.page>

Yellow Taxi files follow this pattern:

```text
https://d37ci6vzurychx.cloudfront.net/trip-data/yellow_tripdata_2025-MM.parquet
```

Replace `MM` with `01` through `06`. Download the zone lookup table from:

```text
https://d37ci6vzurychx.cloudfront.net/misc/taxi_zone_lookup.csv
```

Upload the files to HDFS under:

```text
/data/nyc_tlc_2025/raw/trips
/data/nyc_tlc_2025/raw/zones
```

Raw data and generated outputs are intentionally excluded from this repository.

## Environment

- Hadoop HDFS
- Hive 3.x or compatible HiveServer2
- Spark 3.5.7
- Python 3.8+
- PySpark, pandas, NumPy, matplotlib, GeoPandas, PyArrow

## Run

Start the Spark services using the configuration in `spark-cluster/`, then run:

```bash
spark-submit scripts/nyc_dataset_profile.py
spark-submit scripts/nyc_prepare.py
spark-submit scripts/nyc_hourly_models.py
python scripts/nyc_analyze.py
python scripts/nyc_fig_volume.py
python scripts/nyc_fig_weekday.py
python scripts/nyc_fig_spatial.py
python scripts/nyc_fig_results.py
python scripts/nyc_fig_errors.py
```

Create the Hive tables with:

```bash
beeline -u jdbc:hive2://<hive-host>:10000/default -f scripts/sql/nyc_tables.sql
```
